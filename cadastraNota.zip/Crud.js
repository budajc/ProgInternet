var ObjetoPessoa = {nome: "", nota: "", cpf: "", email: ""};

var index = localStorage.length;

function voltar(){
    window.location.href = "TelaSelecao.html";
}

function atualiza(){
    var nome = document.getElementById("nomelista").value;
    var nota = document.getElementById("notalista").value;
    var cpf = document.getElementById("cpflista").value;
    var email = document.getElementById("emaillista").value;

    ObjetoPessoa.nome = nome;
    ObjetoPessoa.nota = nota;
    ObjetoPessoa.cpf = cpf;
    ObjetoPessoa.email = email;

    localStorage.setItem(index,JSON.stringify(ObjetoPessoa));

}

function entrar() {
    
    let login = document.getElementById("login").value;
    let senha = document.getElementById("senha").value;
    
    if(login == "admin" && senha=="admin"){
        limpalogin();
        window.location.href = "TelaSelecao.html";
    }else{
        alert("Login ou senha incorretos");
    }
}

function excluir(){
    localStorage.removeItem(index);
    alert("Excluido com sucesso");
}

function cadastrar() {
    let nome = document.getElementById("nome").value;
    let nota = document.getElementById("nota").value;
    let cpf = document.getElementById("cpf").value;
    let email = document.getElementById("email").value;

    if(nome == "" || nota == "" || cpf == "" || email == ""){
        alert("Preencha todos os campos");
    }else{
        ObjetoPessoa.nome = nome;
        ObjetoPessoa.nota = nota;
        ObjetoPessoa.cpf = cpf;
        ObjetoPessoa.email = email;

        index = localStorage.length;

        localStorage.setItem(index+1,JSON.stringify(ObjetoPessoa));

        alert("Cadastro realizado com sucesso");
        limpaCadastro();
    }    
}

function limpaCadastro(){
    document.getElementById("nome").value = "";
    document.getElementById("nota").value = "";
    document.getElementById("cpf").value = "";
    document.getElementById("email").value = "";
}

function limpalogin(){
    document.getElementById("login").value = "";
    document.getElementById("senha").value = "";
} 

function modoEscuro(){
   
    document.body.style.backgroundColor = "black";
    document.body.style.color = "white";
}

function modoClaro(){
    document.body.style.backgroundColor = "white";
    document.body.style.color = "black";
}


document.getElementById("listaNota").onload = function(){
    
    let nome = document.getElementById("nomelista");
    let nota = document.getElementById("notalista");
    let cpf = document.getElementById("cpflista");
    let email = document.getElementById("emaillista");

    var objeto = JSON.parse(localStorage.getItem(index));

    nome.value = objeto.nome;
    nota.value = objeto.nota;
    cpf.value = objeto.cpf;
    email.value = objeto.email;
};

function proximo(){
    let nome = document.getElementById("nomelista");
    let nota = document.getElementById("notalista");
    let cpf = document.getElementById("cpflista");
    let email = document.getElementById("emaillista");

    if(index <= localStorage.length){
        index++;
    }

    var objeto = JSON.parse(localStorage.getItem(index));

    nome.value = objeto.nome;
    nota.value = objeto.nota;
    cpf.value = objeto.cpf;
    email.value = objeto.email;


}

function anterior(){
    let nome = document.getElementById("nomelista");
    let nota = document.getElementById("notalista");
    let cpf = document.getElementById("cpflista");
    let email = document.getElementById("emaillista");
    
    

    if(index > 1){
        index--;
    }

    var objeto = JSON.parse(localStorage.getItem(index));
    
    nome.value = objeto.nome;
    nota.value = objeto.nota;
    cpf.value = objeto.cpf;
    email.value = objeto.email;
}